# Copyright Notice
# ================
# WTFPL
# ================
# Tested on Ubuntu, pyMOL 1.7.x, python 2.7.x

import tkSimpleDialog
from Tkinter import *
import tkFileDialog
import tkMessageBox
from pymol import cmd, stored
from tempfile import NamedTemporaryFile
import subprocess as sp
import re, sys, glob,os,shutil
from os.path import expanduser

#TODO Add proper logger and error handling / Refactor GUI and other code/

path = os.path.dirname(__file__)
sys.path.append(path)
home = expanduser("~")

#Const
stored.flags = {}    # 0 -> opt | -1 -> frzn
stored.params = {}
stored.params["PARTIAL_SCRIPT_DIR"] = os.path.join(path, "pdb_to_atq_partial.awk")
stored.params["EXCLUDED_ATOMS"] = "NA,CL"
stored.params["IN_FILES_DIR"] = ""
stored.params["SAVE_DIR"] = ""

def __init__(self):
    self.menuBar.addmenuitem('Plugin', 'command',
                             'QMe',
                             label='QMe',
                             command=lambda s=self: FetchQMeDialog(s))

    self.menuBar.addmenuitem('Plugin', 'command',
                             'QMe PDB loader',
                             label='QMe PDB loader',
                             command=lambda s=self: LoadPdb(s))

def LoadPdb(app):
    """Adds unique numbers to residues higher than 9999, uses chain Id as a placeholder for number"""
    filename = tkFileDialog.askopenfilename(filetypes = (("pdb files","*.pdb"),))
    os.path.basename(filename)
    if(filename):
        with open(filename) as f:
            pdbLines = f.readlines()
        newPdbLines = ReplaceChainWithResId(pdbLines)

        tempPdb = NamedTemporaryFile(delete=False)
        tempPdb.writelines(newPdbLines)
        tempPdb.flush()
        tempPdb.seek(0)

        cmd.load(tempPdb.name, os.path.basename(filename).split('.')[0])
        cmd.alter("all","resi = chain + resi")
        #cmd.sort()

def ReplaceChainWithResId(pdbLines):
    trueResi = 1
    curResi = 1
    newPdbLines = []
    newPdbLines.append(pdbLines[0])
    for line in pdbLines[1:-1]:
        resi = int(line[22:26])
        if (resi != curResi):
            trueResi += 1
            curResi = resi
        newPdbLines.append(line[:21] + '{:5d}'.format(trueResi) + line[26:])
    newPdbLines.append(pdbLines[-1])
    return newPdbLines

#Building GUI
def FetchQMeDialog(app):
    textFields = ('Outer Radius [A]','Optimization Radius [A]')
    selectionFields = ('Center Selection', 'QM Region Selection', 'Link-atoms Selection')
    folderField = ('IN Files Directory', 'Save Directory')
    root = Toplevel()
    root.title("QMe")
    ents = {}
    MakeTextInput(root, textFields, ents)
    MakeSelectionInput(root, selectionFields, ents)
    MakeFolderInput(root, folderField, ents)
    enableLogging = BooleanVar()
    c = Checkbutton(root, text="Save PDB file", variable=enableLogging)
    c.pack(side=RIGHT, padx=4, pady=4)
    b1 = Button(root, text='Convert',
                command=(lambda e=ents,l=enableLogging: Execute(e,l)))
    b1.pack(side=LEFT, padx=7, pady=7)
    root.mainloop()

def MakeTextInput(root, fields, ents):
   for field in fields:
      row = Frame(root)
      lab = Label(row, width=22, text=field+": ", anchor='w')
      ent = Entry(row)
      ent.insert(0,"0")
      row.pack(side=TOP, fill=X, padx=5, pady=5)
      lab.pack(side=LEFT)
      ent.pack(side=RIGHT, expand=YES, fill=X)
      ents[field] = ent

def MakeFolderInput(root, folders, ents):
   for field in folders:
        row = Frame(root)
        lab = Label(row, width=22, text=field+": ", anchor='w')
        ent = Button(row, text="Browse", command=(lambda n=field: BrowseButton(n)))
        row.pack(side=TOP, fill=X, padx=5, pady=5)
        lab.pack(side=LEFT)
        ent.pack(side="top", expand=YES, fill=X)
        ents[field] = ent

def MakeSelectionInput(root, selectionFields, ents):
    for field in selectionFields:
        row = Frame(root)
        lab = Label(row, width=22, text=field + ": ", anchor='w')
        OPTIONS = cmd.get_names("selections")
        if("sele" in OPTIONS):
            OPTIONS.remove("sele")
        var = StringVar(root)
        if(OPTIONS):
            var.set(OPTIONS[0])
        else:
            root.destroy()
            tkMessageBox.showerror('Selection error', 'You need at least one named selection to use QMe')
            raise NameError, "No named selections"
        if field=='Link-atoms Selection':
            OPTIONS = OPTIONS + ['Default', 'None']
        ent = apply(OptionMenu, (row, var) + tuple(OPTIONS))
        row.pack(side=TOP, fill=X, padx=5, pady=5)
        lab.pack(side=LEFT)
        ent.pack(side=RIGHT, expand=YES, fill=X)
        ents[field] = (ent, var)

#GUI functions
def BrowseButton(name):
    filename = tkFileDialog.askdirectory()
    if (not filename):
        filename = ''
    if name == 'IN Files Directory':
        print "IN files directory set as: {}".format(filename)
        stored.params["IN_FILES_DIR"] = filename
    else:
        print "Save directory set as: {}".format(filename)
        stored.params["SAVE_DIR"] = filename

def IsValid(inst):
    if(inst.radiusOuter < 0 or inst.radiusOptimized < 0):
        tkMessageBox.showerror('Invalid radius', 'Radius must be positive')
        return False
    if(inst.radiusOuter < inst.radiusOptimized):
        tkMessageBox.showerror('Invalid radius', 'Outer radius must be greater than optimization radius')
        return False
    return True

def Execute(entries,enableLogging):
    try:
        inst = PDBtoATQ(entries['Center Selection'][1].get(),
                        entries['QM Region Selection'][1].get(),
                        entries['Link-atoms Selection'][1].get(),
                        float(entries['Outer Radius [A]'].get()),
                        float(entries['Optimization Radius [A]'].get()),
                        stored.params["IN_FILES_DIR"],
                        stored.params["SAVE_DIR"],
                        enableLogging.get())
    except:
        tkMessageBox.showerror('Invalid radius', 'Radius must be a number')
    if (IsValid(inst)):
        print "Converting..."
        inst.Convert()

class PDBtoATQ:
    def __init__(self,center, seleQM, seleLA, radiusOuter, radiusOptimized, inFilesDir, saveDir, enableLog):
        self.center = center
        self.radiusOuter = radiusOuter
        self.radiusOptimized = radiusOptimized
        self.seleQM = seleQM
        self.seleLA = seleLA
        self.saveDir = saveDir
        self.inFilesDir = inFilesDir
        self.enableLog = enableLog

    # Public methods
    def Convert(self):
        seleOuter = self.Select("br. all and (not resn WAT (beyond {} of {} )) and (not e. {})"
                                .format(self.radiusOuter, self.center, stored.params["EXCLUDED_ATOMS"]),
                                self.center + "_Outer")

        #Get new object and transfer all selections to new object.
        cmd.alter("all", "if(len(resi) > 4):\n\tresi = resi[1:]")
        outerPdb = self.GetSelectionAsPdb(seleOuter)
        cmd.load(outerPdb.name, "QMe")
        cmd.alter("all", "resi = chain + resi")
        self.TransferSelectionsToNewObject("QMe")

        seleOpt = self.Select(
            "br. all within {} of {} and (not e. {}) and {}".format(self.radiusOptimized, self.center,stored.params["EXCLUDED_ATOMS"], "QMe"), "QMe_Opt")

        offsetList = self.GetOffsetForLinkatomID(outerPdb)  #Bugfix for TER atoms having unique IDs in PDB generated by PyMOL

        #Setting flags
        cmd.iterate_state(1, "QMe", 'stored.flags[("%.3f" % x,"%.3f" % y,"%.3f" % z)]=[-1,"L"]')
        cmd.iterate_state(1, seleOpt, 'stored.flags[("%.3f" % x,"%.3f" % y,"%.3f" % z)][0] = 0')
        cmd.iterate_state(1, self.seleQM, 'stored.flags[("%.3f" % x,"%.3f" % y,"%.3f" % z)][1] = "H"')
        if self.seleLA != 'None':
            self.SetLinkAtomsFlags(outerPdb.name, offsetList)

        # Converting PDB to ATQ
        tempScript = self.AddMissingTypesToScript(self.inFilesDir, stored.params["PARTIAL_SCRIPT_DIR"])
        tempAtq = self.ExecuteScript(outerPdb, tempScript)
        atqParsed = self.ParseAtq(tempAtq)
        atqParsed = self.AddInfoFromFlags(atqParsed)

        self.SerializeAndSaveAtq(atqParsed, self.saveDir)
        print "Done!"

    # Private methods
    def Select(self, command, name):
        cmd.select(command)
        cmd.set_name("sele", name)
        return name

    def GetSelectionAsPdb(self, selectionName):
        tempPdb = NamedTemporaryFile(delete=False)
        tempPdb.write(cmd.get_pdbstr(selectionName))
        tempPdb.seek(0)
        return tempPdb

    def TransferSelectionsToNewObject(self, outerPdbName):
        self.seleQM = self.Select('(all near_to 0.1 of {}) and {}'.format(self.seleQM, outerPdbName), "QMe_QM")
        self.center = self.Select('(all near_to 0.1 of {}) and {}'.format(self.center, outerPdbName), "QMe_Center")
        if(self.seleLA != "None" and self.seleLA != "Default"):
            self.seleLA = self.Select('(all near_to 0.1 of {}) and {}'.format(self.seleLA, outerPdbName), "QMe_LA")

    def GetOffsetForLinkatomID(self, outerPdb):
        i = 0
        offsetList = []
        outerPdb.seek(0)
        outerPdbLines = outerPdb.readlines()
        outerPdb.seek(0)
        for x in outerPdbLines:
            if (x.split(" ")[0] == "TER"):
                i += 1
            offsetList.append(i)
        return offsetList

    #Requires QM flags
    def SetLinkAtomsFlags(self, tempPdb, offsetList):
        if self.seleLA == 'Default':
            self.seleLA = self.Select('neighbor {}'.format(self.seleQM), 'QMe_LA')
        stored.Neighbors = {}
        cmd.iterate_state(1, self.seleLA, 'stored.Neighbors[((ID),("%.3f" % x,"%.3f" % y,"%.3f" % z))]=[]')
        for la in stored.Neighbors.keys():
            cmd.select("id {}".format(la[0]))
            cmd.select("neighbor sele")
            cmd.iterate_state(1, 'sele', 'stored.Neighbors[{}].append((ID,("%.3f" % x,"%.3f" % y,"%.3f" % z)))'.format(la))

        for la in stored.Neighbors.keys():
            for nb in stored.Neighbors[la]:
                if (stored.flags.has_key(nb[1])):
                    if (stored.flags[nb[1]][1] == "H"):
                        offset = offsetList[int(nb[0])-1]
                        stored.flags[la[1]][1] = "L H-HC-0.000001 {}".format(str(int(nb[0])-offset))
                        break

    def AddMissingTypesToScript(self, inFilesDir, partialScriptDir):
        tempScript = NamedTemporaryFile(mode='a+b', delete=False)
        shutil.copy(partialScriptDir, tempScript.name)
        tempScript.seek(0, 2)
        for filename in glob.glob(os.path.join(inFilesDir, '*.in')):
            with open(filename) as f:
                In = f.readlines()
                res_name = re.search("\s*(\S+)", In[4]).group(1)
                In_tpl = re.findall(
                    "^\s*(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)",
                    "".join(In[10:]), re.MULTILINE)

                for line in In_tpl:
                    tempScript.write(
                        '  else if  ($4=="{}" && $3=="{}") {{printf "%s\\t%s\\t%f\\t%12.3f%12.3f%12.3f\\t%s\\n",substr($3,1,1), "{}", $9, $6, $7, $8, "L"}}\n'.format(
                            res_name, line[1], line[2]))

        tempScript.write(
            '  else {printf "%s\\t%s\\t%f\\t%12.3f%12.3f%12.3f\\t%s\\n", substr($3,1,1), "XX", $9, $6, $7, $8, "L"}\n}\n')
        tempScript.flush()
        return tempScript

    def ExecuteScript(self, tempPdb, tempScript):
        tempPdb.seek(0)
        tempScript.seek(0)
        if(self.enableLog):
            with open(os.path.join(stored.params["SAVE_DIR"],"QMe.pdb"),'w') as f:
                f.write(tempPdb.read())
            # with open(os.path.join(stored.params["SAVE_DIR"],"tempScript.awk"),'w') as f:
            #     f.write(tempScript.read())
        tempPdb.seek(0)
        tempScript.seek(0)
        tempAtq = NamedTemporaryFile(delete=False)
        sp.call("awk -f {} {}".format(tempScript.name, tempPdb.name).split(" "), stdout=tempAtq)
        tempAtq.flush()
        tempAtq.seek(0)
        return tempAtq

    def ParseAtq(self, atqFile):
        atqFile.seek(0)
        atq = atqFile.read()
        atqTpl = re.findall("^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+", atq, re.MULTILINE)
        atqArr = map(list, atqTpl)
        return atqArr

    def AddInfoFromFlags(self, atqParsed):
        for line in atqParsed:
            x,y,z = line[3],line[4],line[5]
            if stored.flags.has_key((x, y, z)):
                line.insert(3, stored.flags[(x, y, z)][0])
                line[7] = stored.flags[(x, y, z)][1]
            else: #TER atoms skipped
                line.insert(3, "0")
                line[7] = "L"
        return atqParsed

    def SerializeAndSaveAtq(self, atqParsed, saveDir):
        with open(os.path.join(saveDir, "out.atq"), "w") as f:
            for atom, typ, ch, optflag, x, y, z, oniom in atqParsed:
                try:
                    f.write("%s\t%s\t%s\t%s\t%12.3f%12.3f%12.3f\t%s\n" % (
                        atom, typ, ch, optflag, float(x), float(y), float(z), oniom))
                except:
                    with open(os.path.join(stored.params["SAVE_DIR"], "atqParsedFinErrors.txt"), "w") as f:
                        f.write("{} {} {} {} {} {} {} {}\n".format(atom,typ,ch,optflag,x,y,z,oniom))
